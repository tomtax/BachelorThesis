### --------------------------- ###
### FORWARD LINKAGES ESTIMATION ###
### --------------------------- ###

# Prerequisites #
rm(list = ls())

# Packages needed in order to run this code
library(data.table)
library(readxl)
library(dplyr)
# packages useful for importing figures into LaTex
library(foreign)
library(xtable)
library(stargazer)


# ------------ # 
# Loading data #
# ------------ #
setwd("C:/INSERT/PATH/TO/YOUR/WORKING/DIRECTORY") 
load("WIOT2014_October16_ROW.RData") #load WIOD tables http://www.wiod.org/database/wiots16

# Transforming to basic matrices
wiot.MATRIX <- data.matrix(wiot) #WIOT number values only
transaction.MATRIX <- wiot.MATRIX[1:2464,6:2469] #transaction matrix Z 
finaloutput_total.RVECTOR <- wiot.MATRIX[2472,6:2469] #total outlays - only row 
finaloutput_total.CVECTOR <- wiot.MATRIX[1:2464,2690] #total outputs - column
finuse.MATRIX <- wiot.MATRIX[1:2464,2470:2689] #final demand matrix f
finuse.Czech.MATRIX <- finuse.MATRIX[,46:50]  #domestic final demand - only values belonging to CZE
sector_countries_descriptor <- (wiot[1:2464,1:3])
cnames <- colnames(wiot)
cnames.sectors <- cnames[6:2469]
mat_dim <- ncol(transaction.MATRIX)


# ---------------------------- # 
# Input-Output Framework setup #
# The Ghosh model              # 
# ---------------------------- #

# Getting total final demands by countries - i.e. getting VECTOR (not matrix) f 
# There are 44 regions, each with 5 final demand column vectors
# It is done using an "aggregation matrix"
# Aggregation matrix contains 1 where country (row) = country (col), 0 elsewhere
# i.e. it is (sort of) diagonal with 5 ones in each column

# Generating aggregation matrix
n_countries <- 44
agreg_finuse.MATRIX <- matrix(0, nrow = n_countries*5, ncol=n_countries)
j <- 1
k <- 1
while (j <= n_countries*5)
{
  for (a in 0:4)
  {agreg_finuse.MATRIX[j:j+a,k]<- 1}
  j <- j + 5
  k <- k + 1
}

# Aggregating final use
fin_use.MATRIX <- finuse.MATRIX %*% agreg_finuse.MATRIX
total_fin_use.CVECTOR <- rowSums(fin_use.MATRIX)
finuse_output_coefs.CVECTOR <- total_fin_use.CVECTOR/finaloutput_total.CVECTOR 
CZ_airtrans_finuse <- total_fin_use.CVECTOR[537]


# We need to cover complete Output of the economy
# We need all components of VA -> sum VA rows
# Aggregation value added components
Total_VA.RVECTOR <- rep(0, mat_dim) #create empty vector, to be overwritten

for (j in 1:mat_dim) {
  Total_VA.RVECTOR[j] <- wiot.MATRIX[2466,j+5] + wiot.MATRIX[2467,j+5] + 
                         wiot.MATRIX[2468,j+5] + wiot.MATRIX[2469,j+5] + 
                         wiot.MATRIX[2470,j+5] + wiot.MATRIX[2471,j+5]  
}


# Allocation coefficients (B) matrix calculation
  # Preparing objects for B matrix calculation
B.MATRIX <- transaction.MATRIX # creating a copy of the transaction matrix


# Calculating B matrix (zero outputs possible where no transactions)
for (i in 1:mat_dim) # B=[b_ij], where b_ij = z_ij/x_i
{
  if (finaloutput_total.RVECTOR[i] > 0)
  {B.MATRIX[i,]<-B.MATRIX[i,]/finaloutput_total.RVECTOR[i]}  
  if (finaloutput_total.RVECTOR[i] == 0) 
  {B.MATRIX[i,]<-B.MATRIX[i,]*0}
}

# Ghosh inversion
IminB.MATRIX <- diag(mat_dim) - (B.MATRIX) # (I-B)
Ghosh.MATRIX <- solve(IminB.MATRIX) # (I-B) inverse = G


# Calculating total output and final demand
Output_calculated <- t(Ghosh.MATRIX) %*% Total_VA.RVECTOR # x'=v'G <=> x = G'v

# possible indicative decomposition of final demand and intermediate production
#finuse_calculated <- Output_calculated * finuse_output_coefs.CVECTOR # use observed VA coefs
#Intermediate_Out_Calc <- Output_calculated - finuse_calculated

# At this point, the initial Ghosh model is set up.



# ------------------------------ #
# Hypothetical Extraction Method #
# ------------------------------ #

# Extraction of the Czech Air Transport industry 
# Creating the extraction matrix
extra_par.V <- rep(1, mat_dim)
HEM.MATRIX <- matrix(1, nrow = mat_dim, ncol = mat_dim)

for (z in 537:537){ 
  extra_par.V[z] = 0
  HEM.MATRIX[z,] = 0
  }

for (z in 1:mat_dim) {
      HEM.MATRIX[z,z] = 1
}

#sum(HEM.MATRIX[537,]) #check that only intraindustry transactions remain

# Applying the hypothetical extraction on the B matrix
B.HEM.MATRIX <- B.MATRIX * HEM.MATRIX # nulls the extracted sector

# Adjusting the value added vector
# Total_VA.RVECTOR <- Total_VA.RVECTOR * extra_par.V # HEM v

# Ghosh inverse for the hypothetical extraction
IminB.HEM <- diag(ncol(B.HEM.MATRIX)) - B.HEM.MATRIX # (I-B)
Ghosh.HEM.MATRIX <- solve(IminB.HEM) # (I-B) inverse

# Calculating total output and value added after hypothetical extraction
Output.HEM <- t(Ghosh.HEM.MATRIX) %*% Total_VA.RVECTOR# x' = v'G <=> x = G'v

# possible indicative decomposition of final demand and intermediate production
#finuse.HEM <- Output.HEM * finuse_output_coefs.CVECTOR
#Intermediate_Out.HEM <- Output.HEM - finuse.HEM



# -------------------- # 
# Results presentation #
# -------------------- #

# Total Output Results
# --------------------

# World # 
Abs_effect <- Output.HEM - Output_calculated # non-positive numbers - absolute change in output
Perc_effect <- (Output.HEM/Output_calculated - 1)*100 # percentage decrease in output
Total_abs_effect <- sum(Output.HEM) - sum(Output_calculated) # change in world Total Output 
Total_perc_effect <- Total_abs_effect/sum(Output_calculated)*100 # % change in world Total Output
#Int_abs_effect <- Intermediate_Out.HEM - Intermediate_Out_Calc # Intermediate output effect is the same as total effect
#Int_perc_effect <- (Intermediate_Out.HEM/Intermediate_Out_Calc - 1)*100
#Total_int_abs_effect <- sum(Intermediate_Out.HEM) - sum(Intermediate_Out_Calc) # same as Total Output effect
#Total_int_perc_effect <- Total_int_abs_effect/sum(Intermediate_Out_Calc)*100 # % change in world intermediate Output  

Output_effects <- data.table(sector_countries_descriptor,  Output_calculated, Output.HEM, Abs_effect, Perc_effect)
setnames(Output_effects,c("ISIC","Industry","Country","Total output", "Total output HEM","Output change","Output change (%)")) 

# Czech Republic # 
Output_CZE <- subset(Output_effects,Country == "CZE") # choose only Czech sectors
Total_abs_effect_CZE <- sum(Output_CZE[,"Output change"], na.rm = TRUE) # total decrease of CZE output
Total_perc_effect_CZE <- Total_abs_effect_CZE / sum(Output_CZE[, "Total output"]) * 100 # % CZE decrease
#Intermediate_perc_effect_CZE <- Total_abs_effect_CZE / sum(Output_CZE[, "Interm. output"]) * 100

# Prep for export into LaTex
# Ranking by the most affected sectors in the Czech Republic
rank_CZE_R <- c(rank(Output_CZE[, "Output change (%)"]))
Output_effects_CZE_R <- data.table(Output_CZE, rank_CZE_R)
Output_effects_CZE_R <-setorder(Output_effects_CZE_R, rank_CZE_R)

rank_CZE_A <- c(rank(Output_CZE[, "Output change"]))
Output_effects_CZE_A <- data.table(Output_CZE, rank_CZE_A)
Output_effects_CZE_A <-setorder(Output_effects_CZE_A, rank_CZE_A)

# Most hit CZE sectors - Output
# First, predefine how many most hit sectors we want to display
r <- 10 # including the extracted industry
r <- r+1
TopR_CZE_A <- subset(Output_effects_CZE_A, rank_CZE_A < r ) # absolute terms
TopR_CZE_R <- subset(Output_effects_CZE_R,  rank_CZE_R <= r) # relative terms



# -------------------------------- #
# Exporting the results into LaTex #
# -------------------------------- # 

# choose the contents of the demanded tables
# Output
Output_effects_CZE_A <- Output_effects_CZE_A[,c("Country", "Industry", "rank_CZE_A" ):=NULL]
Output_effects_CZE_R <- Output_effects_CZE_R[,c("Country", "Industry", "rank_CZE_R"):=NULL]
Output_CZE <- Output_CZE[,c("Country", "ISIC"):=NULL]
TopR_CZE_A <- TopR_CZE_A[,c("Country", "rank_CZE_A", "ISIC"):=NULL] 
TopR_CZE_R <- TopR_CZE_R[,c("Country", "rank_CZE_R" , "ISIC"):=NULL]

# Save figures
# Output
print(xtable(Output_effects_CZE_R, type = "latex", digits=c(0,0,1,1,1,2)), file = "FL_AirTrans_Output_effects_CZE_relative_rank_short.tex")
print(xtable(Output_effects_CZE_A, type = "latex", digits=c(0,0,1,1,1,2)), file = "FL_AirTrans_Output_effects_CZE_absolute_rank_short.tex")
print(xtable(Output_CZE, type = "latex", digits=c(0,0,1,1,1,2)), file = "FL_AirTrans_Output_effects_CZE_no_rank_short.tex")
print(xtable(TopR_CZE_A, type = "latex", digits=c(0,0,1,1,1,2)), file = "FL_AirTrans_TopR_Output_effects_CZE_absolute_rank_short.tex")
print(xtable(TopR_CZE_R, type = "latex", digits=c(0,0,1,1,1,2)), file = "FL_AirTrans_TopR_Output_effects_CZE_relative_rank_short.tex")

